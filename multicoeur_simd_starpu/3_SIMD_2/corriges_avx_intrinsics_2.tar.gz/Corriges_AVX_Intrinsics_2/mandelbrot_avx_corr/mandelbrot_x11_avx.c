#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <immintrin.h>

/* Size in bytes of an SIMD register */
#define REG_BYTES (sizeof(__m256))

/* Number of elements in an SIMD register */
#define REG_NB_ELEMENTS (REG_BYTES / sizeof(float))



#define win_width  512
#define win_height 512
#define module_threshold (1.0e10)

#define loop_min_threshold 1
#define loop_max_threshold 255

static float view_width=2;
static float view_height=2;
static float orig_x=-0.5;
static float orig_y=-0.0;

static int loop_threshold=loop_min_threshold;

static int colormap[loop_max_threshold];

/* XWindow objects*/
static Display *display = (Display *)NULL;
static Window root_window;
static int screen = -1;
static int depth = -1;
static Visual *visual = (Visual *)NULL;
static Window window ;
static XSetWindowAttributes win_attr;
static GC win_gc;
static XImage *blit_image = NULL;

static int32_t *mand_array = NULL;

static void
init_colormap(void) {
	for (int i=0; i<loop_max_threshold; i++) {
		colormap[i] = !!(i&1) * 0xff + !!(i&2) * 0xff00 + !!(i&4)*0xff0000;
	}
}

static void
update_mand_array(void) {
	assert(win_width % REG_NB_ELEMENTS == 0);
	const float scale_x = view_width / (float)win_width;
	const float scale_y = view_height / (float)win_height;
	const float display_offset_x = win_width / 2;
	const float display_offset_y = win_height / 2;
	float element_offset[REG_NB_ELEMENTS];
	for (unsigned i=0; i<REG_NB_ELEMENTS; i++)
	{
		element_offset[i] = i;
	}
	const __m256 reg_element_offset = _mm256_load_ps(&element_offset[0]);
	const __m256i reg_loop_threshold = _mm256_set1_epi32(loop_threshold);
	const __m256 reg_module_threshold = _mm256_set1_ps(module_threshold);
	const __m256 reg_display_offset_x = _mm256_set1_ps(display_offset_x);
	const __m256 reg_display_offset_y = _mm256_set1_ps(display_offset_y);
	const __m256 reg_scale_x = _mm256_set1_ps(scale_x);
	const __m256 reg_scale_y = _mm256_set1_ps(scale_y);
	const __m256 reg_orig_x = _mm256_set1_ps(orig_x);
	const __m256 reg_orig_y = _mm256_set1_ps(orig_y);
	const __m256i reg_1 = _mm256_set1_epi32(1);

	for (int y = 0; y < win_height ; y++) {
		const __m256 reg_y = _mm256_set1_ps(y);
		const __m256 reg_cb = _mm256_add_ps(_mm256_mul_ps((_mm256_sub_ps(reg_y, reg_display_offset_y)), reg_scale_y), reg_orig_y);

		for (int x = 0; x+REG_NB_ELEMENTS <= win_width ; x+=REG_NB_ELEMENTS) {
			const __m256 reg_x = _mm256_add_ps(reg_element_offset, _mm256_set1_ps(x));
			const __m256 reg_ca = _mm256_add_ps(_mm256_mul_ps((_mm256_sub_ps(reg_x, reg_display_offset_x)), reg_scale_x), reg_orig_x);
			__m256 reg_xa = reg_ca;
			__m256 reg_xb = reg_cb;
			__m256 reg_xa2 = _mm256_mul_ps(reg_xa, reg_xa);
			__m256 reg_xb2 = _mm256_mul_ps(reg_xb, reg_xb);
			__m256i reg_nb_iter = reg_1;

			for (int i=0; i<loop_threshold; i++) {
				const __m256 reg_new_xa = _mm256_add_ps(_mm256_sub_ps(reg_xa2, reg_xb2), reg_ca);
				const __m256 reg_xa_xb = _mm256_mul_ps(reg_xa, reg_xb);
				const __m256 reg_new_xb = _mm256_add_ps(_mm256_add_ps(reg_xa_xb, reg_xa_xb), reg_cb);
				reg_xa = reg_new_xa;
				reg_xb = reg_new_xb;
				reg_xa2 = _mm256_mul_ps(reg_xa, reg_xa);
				reg_xb2 = _mm256_mul_ps(reg_xb, reg_xb);

				const __m256 reg_norm = _mm256_add_ps(reg_xa2, reg_xb2);
				const __m256i reg_norm_mask = _mm256_castps_si256 (_mm256_cmp_ps(reg_norm, reg_module_threshold, _CMP_LT_OQ));
				if (_mm256_testz_si256(reg_norm_mask, reg_norm_mask))
					break;
				reg_nb_iter = _mm256_add_epi32(reg_nb_iter, _mm256_and_si256(reg_1, reg_norm_mask));
			}

			const __m256i reg_loop_mask = _mm256_cmpgt_epi32(reg_loop_threshold, reg_nb_iter);
			reg_nb_iter = _mm256_and_si256(reg_nb_iter, reg_loop_mask);
			const __m256i reg_pixel = _mm256_i32gather_epi32(colormap, reg_nb_iter, 4);
			_mm256_store_si256((__m256i *)&(mand_array[win_width*y+x]), reg_pixel);
		}
	}
	loop_threshold = loop_threshold+1;
	if (loop_threshold > loop_max_threshold) {
		loop_threshold = loop_min_threshold;
	}
}

static void
display_mand_array(void) {
	int err;
	if ((err = XPutImage(display, window, win_gc, blit_image, 0, 0, 0, 0, win_width, win_height))) {
		fprintf(stderr, "XPutImage failed\n");
		exit(1);
	}
	XSync(display, False);
}

static void
display_f(void) {
	update_mand_array();
	display_mand_array();
}

int
main(int argc, char ** argv) {
	init_colormap();
	display = XOpenDisplay(0);
	if (display == (Display *)NULL) {
		(void)fprintf(stderr, "XOpenDisplay failed\n");
		exit(1);
	}

	root_window = DefaultRootWindow(display);
	screen = DefaultScreen(display);
	depth = DefaultDepth(display, screen);

	//visual = DefaultVisual(display, screen);
	{
		/* find a 24-bit visual */
		XVisualInfo visual_24bit_info;
		if (!XMatchVisualInfo(display, screen, 24, TrueColor, &visual_24bit_info)) {
			fprintf(stderr, "24-bit visual not found\n");
			exit(1);
		}
		visual = visual_24bit_info.visual;
	}

	/* Init window */
	memset(&win_attr, 0, sizeof(XSetWindowAttributes));
	win_attr.background_pixel = 0;
	win_attr.border_pixel = 0;
	win_attr.colormap = XCreateColormap(display, root_window, visual, AllocNone);
	window = XCreateWindow(display,
			root_window,
			0, 0,
			win_width, win_height,
			0,
			depth,
			InputOutput,
			visual,
			CWBackPixel|CWBorderPixel|CWColormap, &win_attr);

	/* Set window title */
	XStoreName(display, window, "X11 Window");

	/* Initialize which set of events we want to handle */
	XSelectInput(display, window, KeyPressMask);

	/* Show the window on the display */
	XMapWindow (display, window);

	/* Sync XWindow command queue */
	XSync(display, True) ;

	/* Create a graphic context for the window */
	win_gc = XCreateGC(display, window, 0L, 0);

	/* Allocate an AVX2 aligned mand_array */
	mand_array = aligned_alloc(REG_BYTES, win_width*win_height*sizeof(*mand_array));
	assert(mand_array != NULL);

	/* Create a X11 wrapper for our mand_array */
	if (!(blit_image = XCreateImage(display, NULL, 24, ZPixmap, 0, (char*)mand_array, win_width, win_height, 32, 0))) {
		fprintf(stderr, "XCreateImage failed\n");
		exit(1);
	}

	/* Update and display mand array */
	display_f();

	for (;;) {
		XEvent event;

		if (XCheckTypedEvent(display, KeyPress, &event) == True) {
			switch (event.type) {
				case KeyPress:
					exit(0);
					break;
				default:
					fprintf(stderr, "unhandled X11 event\n");
					exit(1);
			}
		}
		display_f();
	}
	free(mand_array);

	return 0;
}

